import { db, ref, push, onChildAdded, update } from "./firebase.js";
const user=localStorage.getItem("user");
const feedRef=ref(db,"posts");
window.post=()=>{
push(feedRef,{user,text:document.getElementById("text").value,likes:0});
document.getElementById("text").value="";
};
onChildAdded(feedRef,s=>{
const p=s.val();
document.getElementById("feed").innerHTML=
`<div class="post"><b>${p.user}</b><br>${p.text}
<div class="actions">
<span onclick="like('${s.key}',${p.likes})">👍 Like (${p.likes})</span>
<span>💬 Comment</span>
<span>🔁 Share</span>
</div></div>`+document.getElementById("feed").innerHTML;
});
window.like=(id,c)=>{update(ref(db,"posts/"+id),{likes:c+1});};
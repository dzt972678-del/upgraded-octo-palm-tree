function login(){
localStorage.setItem("user",document.getElementById("name").value);
location.href="feed.html";
}
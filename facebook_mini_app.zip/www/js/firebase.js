import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.0/firebase-app.js";
import { getDatabase, ref, push, onChildAdded, update } from "https://www.gstatic.com/firebasejs/10.7.0/firebase-database.js";
const firebaseConfig={databaseURL:"https://cuytt-74ff5-default-rtdb.asia-southeast1.firebasedatabase.app"};
export const app=initializeApp(firebaseConfig);
export const db=getDatabase(app);
export {ref,push,onChildAdded,update};
import { db, ref, push, onChildAdded } from "./firebase.js";
const user=localStorage.getItem("user");
const chatRef=ref(db,"chat");
window.send=()=>{
push(chatRef,{user,text:document.getElementById("msg").value});
document.getElementById("msg").value="";
};
onChildAdded(chatRef,s=>{
const d=s.val();
document.getElementById("box").innerHTML+=`<p><b>${d.user}</b>: ${d.text}</p>`;
});